<?php
    header("Location: config.php");
    die();
?>
